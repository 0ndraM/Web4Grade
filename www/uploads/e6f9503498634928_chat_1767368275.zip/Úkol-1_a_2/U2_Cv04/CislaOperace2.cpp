#include "CislaOperace2.h"
#include <iostream>


CislaOperace2::CislaOperace2() {}

CislaOperace2::~CislaOperace2() {}

// ---

// ----------------------------------------------------------------
// Domaci ukol - reseni:

int CislaOperace2::faktorialNerek(int n)
{
	/*
	 * Vyhodnoceni slozitosti algoritmu:
	 *
	 * Vstup: n (prirozene cislo)
	 *
	 * Casova slozitost (Time Complexity):
	 * - Pocet operaci je primarne urcen cyklem 'for'.
	 * - Cyklus 'for' se provede (n - 2) krat (pro i = 2 az n-1).
	 * - Celkova casova slozitost je tedy primo umerna hodnote n.
	 * - O(n) - Linearni slozitost.
	 *
	 * Pametova slozitost (Space Complexity):
	 * - Algoritmus pouziva konstantni mnozstvi pameti.
	 * - O(1) - Konstantni slozitost.
	 */
	int f = 1;
	for (int i = 2; i < n; i++)
		f *= i;
	return f;
}

int CislaOperace2::mocninaR(int c, int m)
{
	/*
	 * Vyhodnoceni slozitosti algoritmu:
	 *
	 * Vstup: c (zaklad), m (exponent, prirozene cislo)
	 *
	 * Casova slozitost (Time Complexity):
	 * - Rekurze se provede celkem (m + 1) krat.
	 * - Celkova casova slozitost je primo umerna hodnote m.
	 * - O(m) - Linearni slozitost vzhledem k exponentu.
	 *
	 * Pametova slozitost (Space Complexity):
	 * - Pametova narocnost je urcena hloubkou rekurze (zasobnik volani), ktera je m + 1.
	 * - O(m) - Linearni slozitost vzhledem k exponentu.
	 */
	if (m == 0)
		return 1;
	mocninaR(c, m - 1);
}

int CislaOperace2::mocninaNerek(int c, int m)
{
	/*
	 * Vyhodnoceni slozitosti algoritmu:
	 *
	 * Vstup: c (zaklad), m (exponent, prirozene cislo)
	 *
	 * Casova slozitost (Time Complexity):
	 * - Pocet operaci je primarne urcen cyklem 'for', ktery se provede m krat.
	 * - O(m) - Linearni slozitost vzhledem k exponentu.
	 *
	 * Pametova slozitost (Space Complexity):
	 * - Algoritmus pouziva konstantni mnozstvi pameti.
	 * - O(1) - Konstantni slozitost.
	 */
	int v = 1;
	for (int i = 0; i < m; i++)
		v *= v * i;
	return v;
}

int CislaOperace2::zjistiPocetKladnych(int* hodnoty, int n)
{
	/*
	 * Vyhodnoceni slozitosti algoritmu:
	 *
	 * Vstup: hodnoty (pole celých cisel), n (velikost pole)
	 *
	 * Casova slozitost (Time Complexity):
	 * - Pocet operaci je primarne urcen cyklem 'for', ktery se provede n krat.
	 * - Celkova casova slozitost je primo umerna velikosti vstupu n.
	 * - O(n) - Linearni slozitost.
	 *
	 * Pametova slozitost (Space Complexity):
	 * - Algoritmus pouziva konstantni mnozstvi pameti (nepocitame-li vstupni pole).
	 * - O(1) - Konstantni slozitost.
	 */
	int kolik = 0;
	for (int i = 0; i < n; i++)
		if (hodnoty[i] > 0)
			kolik++;
	return kolik;
}