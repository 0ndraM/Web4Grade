#include "CislaOperace2.h"
#include <iostream>
using namespace std;

int main()
{
    CislaOperace2 c;

    cout << "=== Test faktorialNerek ===" << endl;
    cout << "0! = " << c.faktorialNerek(0) << endl;
    cout << "1! = " << c.faktorialNerek(1) << endl;
    cout << "5! = " << c.faktorialNerek(5) << endl;
    cout << "-3! = " << c.faktorialNerek(-3) << " (chybn� vstup)" << endl;

    cout << "\n=== Test mocninaR ===" << endl;
    cout << "2^0 = " << c.mocninaR(2, 0) << endl;
    cout << "2^3 = " << c.mocninaR(2, 3) << endl;
    cout << "5^1 = " << c.mocninaR(5, 1) << endl;

    cout << "\n=== Test mocninaNerek ===" << endl;
    cout << "3^0 = " << c.mocninaNerek(3, 0) << endl;
    cout << "3^4 = " << c.mocninaNerek(3, 4) << endl;

    cout << "\n=== Test zjistiPocetKladnych ===" << endl;
    int pole1[] = { 1, -2, 3, 0, 5, -1 };
    cout << "Pocet kladnych v {1,-2,3,0,5,-1}: "
        << c.zjistiPocetKladnych(pole1, 6) << endl;

    int pole2[] = { -1, -5, -10 };
    cout << "Pocet kladnych v {-1,-5,-10}: "
        << c.zjistiPocetKladnych(pole2, 3) << endl;

    return 0;
}
