#include "CislaOperace2.h"
#include <iostream>

CislaOperace2::CislaOperace2() {}

CislaOperace2::~CislaOperace2() {}

// Nerekurzivn� v�po�et faktori�lu
int CislaOperace2::faktorialNerek(int n)
{
    if (n < 0) return -1; // faktori�l pro z�porn� ��slo neexistuje
    int vysledek = 1;
    for (int i = 1; i <= n; i++)
        vysledek *= i;
    return vysledek;
}

// Rekurzivn� v�po�et mocniny
int CislaOperace2::mocninaR(int c, int m)
{
    if (m < 0)
        return 0; // pro z�porn� mocniny zat�m ne�e��me (necel� ��sla)
    if (m == 0)
        return 1;
    return c * mocninaR(c, m - 1);
}

// Nerekurzivn� v�po�et mocniny
int CislaOperace2::mocninaNerek(int c, int m)
{
    if (m < 0)
        return 0;
    int vysledek = 1;
    for (int i = 0; i < m; i++)
        vysledek *= c;
    return vysledek;
}

// Zjist� po�et kladn�ch ��sel v poli
int CislaOperace2::zjistiPocetKladnych(int* hodnoty, int n)
{
    if (n <= 0 || hodnoty == nullptr)
        return 0;

    int pocet = 0;
    for (int i = 0; i < n; i++)
        if (hodnoty[i] > 0)
            pocet++;
    return pocet;
}
